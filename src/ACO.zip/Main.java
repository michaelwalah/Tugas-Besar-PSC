
import Algorithm.AntColony;
import java.io.IOException;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author William Walah
 */
public class Main {
    public static void main(String[] args) throws IOException {
        AntColony aco = new AntColony();
        aco.run();
    }
}
